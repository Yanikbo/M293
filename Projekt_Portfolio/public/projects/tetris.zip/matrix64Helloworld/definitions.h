#include "WString.h"
#include "esp32-hal-gpio.h"
#include <sys/_intsup.h>
#include <Arduino.h>
#include <ESP32-HUB75-VirtualMatrixPanel_T.hpp>
#include <Preferences.h>

#ifdef BEENHERE
#define BEENHERE
#endif
//#define ARDUINO_NANO
#define ESPRESSIF
/**
  * Configuration of the LED matrix panels number and individual pixel resolution.
  **/

#define PANEL_RES_X 64                                     // Number of pixels wide of each INDIVIDUAL panel module.
#define PANEL_RES_Y 64                                     // Number of pixels tall of each INDIVIDUAL panel module.
#define VDISP_NUM_ROWS 1                                   // Number of rows of individual LED panels
#define VDISP_NUM_COLS 1                                   // Number of individual LED panels per row
#define PANEL_CHAIN_LEN (VDISP_NUM_ROWS * VDISP_NUM_COLS)  // Don't change
#define PANEL_CHAIN_TYPE CHAIN_TOP_RIGHT_DOWN
#define PANEL_SCAN_TYPE FOUR_SCAN_32PX_HIGH

MatrixPanel_I2S_DMA* dma_display = nullptr;
VirtualMatrixPanel_T<PANEL_CHAIN_TYPE>* display = nullptr;


// ----------------------------------------------------------------------§§§        --------------------------------------
typedef struct {   //Bouncing Rectangles Info's
  int xPos;        //aktuelle x Position des Rechtecks
  bool direction;  //aktulle richtung
  int speed;       //Speed als Vielfaches des delays
  uint16_t color;
  int yPosition;  // y yPosition
} bounceInfo;

struct blocks {
  int x;
  int y;
};

struct scores {
  char name[4];
  int nscore;
};
//--------------------------------------------Alle globale Variabeln über alle files-------------------------
blocks shapes[7][4] = {
  { { 0, 0 }, { 0, 1 }, { 0, 2 }, { 0, 3 } },  // IBlock
  { { 0, 0 }, { 0, 1 }, { 0, 2 }, { 1, 2 } },  // LBlock
  { { 1, 0 }, { 1, 1 }, { 1, 2 }, { 0, 2 } },  // reverseLBlock
  { { 0, 0 }, { 0, 1 }, { 1, 0 }, { 1, 1 } },  // quader
  { { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 2 } },  // ZBlock
  { { 1, 0 }, { 1, 1 }, { 0, 1 }, { 0, 2 } },  // reverseZBlock
  { { 0, 0 }, { 0, 1 }, { 0, 2 }, { 1, 1 } }   // TBlock
};

blocks nextshapes[7][4] = {
  { { 0, 0 }, { 0, 1 }, { 0, 2 }, { 0, 3 } },  // IBlock
  { { 0, 0 }, { 0, 1 }, { 0, 2 }, { 1, 2 } },  // LBlock
  { { 1, 0 }, { 1, 1 }, { 1, 2 }, { 0, 2 } },  // reverseLBlock
  { { 0, 0 }, { 0, 1 }, { 1, 0 }, { 1, 1 } },  // quader
  { { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 2 } },  // ZBlock
  { { 1, 0 }, { 1, 1 }, { 0, 1 }, { 0, 2 } },  // reverseZBlock
  { { 0, 0 }, { 0, 1 }, { 0, 2 }, { 1, 1 } }   // TBlock
};
int randomblock;
int xPos = 4;
int yPos = -1;
int feldHoehe = 16;
int blockhoehe;
int feldBreite = 9;
bool bewegung = true;
uint16_t color;
int colorstate = 1;
uint16_t menucolor = display->color565(123,86,255);
uint16_t textcolor = 0;
int pivotX;
int pivotY;
int millisecond = 0;
bool notquader = true;
int globalblocksize;
bool spielfeldraster[9][16] = { false };
int posX;
int posY;
int gamemode = 5;
int nextblock;
int level = 1;
bool voll = true;
int punktzahl = 0;
int anzahlreihen = 0;
int levelspeed = 50;
int highscore = 0;
char Buchstabe = 'A';
int buchstabenlocker = 1;
bool lastState = LOW;
bool lastStateleft = LOW;
char ersterbuchstabe;
char zweiterbuchstaben;
char dritterbuchstaben;
bool okay = false;
scores topscores[3];
char namensbuchstaben[4] = {'A', 'A', 'A','\0'};
Preferences preferences;
scores sc;
//int newScore;
scores newScore;
bool scoreeingetragen = false;
// ------------------------------------------------------------------------------------------------------------

void initMatrix() {
#ifdef ARDUINO_NANO
#define RL1 5  //brown
#define GL1 6  //red
#define BL1 7  //Orange
#define RL2 8  //green

#define GL2 9   //blue
#define BL2 10  //violet

#define CH_A 2  //white
#define CH_B 3  //Black
#define CH_C 4  //Brown

#define CH_D 11  //red
#define CH_E 12  //gray

#define CLK 38  //Orange
#define LAT 21  //yellow
#define OE 18   //green
  //GNd             //blue und Yellow
#endif

#ifdef ESPRESSIF
#define RL1 7   //brown
#define GL1 15  //red
#define BL1 16  //Orange
#define RL2 17  //green

#define GL2 18  //blue
#define BL2 8   //violet

#define CH_A 46  //white
#define CH_B 9   //Black
#define CH_C 10  //Brown

#define CH_D 11  //red

#define CH_E 3  //gray

#define CLK 12  //Orange
#define LAT 13  //yellow
#define OE 14   //green
  //GNd             //blue und Yellow
#endif


  HUB75_I2S_CFG::i2s_pins _pins = { RL1, GL1, BL1, RL2, GL2, BL2, CH_A, CH_B, CH_C, CH_D, CH_E, LAT, OE, CLK };
  // Standard panel type natively supported by this library (Example 1, 4)
  HUB75_I2S_CFG mxconfig(
    PANEL_RES_X,
    PANEL_RES_Y,
    PANEL_CHAIN_LEN, _pins);

  mxconfig.i2sspeed = HUB75_I2S_CFG::HZ_10M;
  //mxconfig.clkphase = false;// <------------- Turn off double buffer and it'll look flickery
  mxconfig.double_buff = true;  // <------------- Turn on double buffer

  /**
    * Setup physical DMA LED display output.
    */
  dma_display = new MatrixPanel_I2S_DMA(mxconfig);
  dma_display->begin();
  dma_display->setBrightness8(64);  //0-255
  dma_display->clearScreen();

  /**
    * Setup the VirtualMatrixPanel_T class to map the virtual pixels to the physical pixels.
    */
  display = new VirtualMatrixPanel_T<PANEL_CHAIN_TYPE>(VDISP_NUM_ROWS, VDISP_NUM_COLS, PANEL_RES_X, PANEL_RES_Y);

  // Pass a reference to the DMA display to the VirtualMatrixPanel_T class
  display->setDisplay(*dma_display);
}
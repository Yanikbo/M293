#include <Arduino.h>
#include <ESP32-HUB75-VirtualMatrixPanel_T.hpp>
#include "definitions.h"
#include "Tetris_file2.h"
#include "Tetris_file3.h"
#include "tetris_file1.h"
#include "Tetris_file4.h"

//#include "tetrisdefinition.h"




void setup() {
  pinMode(39, INPUT_PULLUP);
  pinMode(38, INPUT_PULLUP);
  pinMode(35, INPUT_PULLUP);
  pinMode(37, INPUT_PULLUP);
  Serial.begin(115200);
  initMatrix();
  intinierungrangking();
  //intinierunghighscore();
}

void loop() {
  tetris2();
  tetris3();
  tetris1();
  Tetris4();
}

#include "Arduino.h"
#include <memory>
#include "HardwareSerial.h"
#include <cstdlib>
#include "esp32-hal-gpio.h"
#include <Preferences.h>


int blockheight(blocks shape[4]) {  //berechnet immer die aktuelle Höhe des Blocks
  int maxY = 0;
  for (int i = 0; i < 4; i++) {
    if (shape[i].y > maxY) {
      maxY = shape[i].y;
    }
  }
  return maxY + 1;
}

int blockwidth(blocks shape[4]) {  //berechnet immer die aktuelle breite des Blocks
  int maxX = 0;
  for (int i = 0; i < 4; i++) {
    if (shape[i].x > maxX) {
      maxX = shape[i].x;
    }
  }
  return maxX + 1;
}

void drawblock(int rasterX, int rasterY, uint16_t color, blocks shape[4], int blocksize) {  //zeichnet den Block auf das Raster und macht das Raster
  for (int i = 0; i < 4; i++) {
    int pixelX = (rasterX + shape[i].x) * blocksize;
    int pixelY = (rasterY + shape[i].y) * blocksize;
    display->fillRect(pixelX, pixelY, blocksize, blocksize, color);
    globalblocksize = blocksize;
  }
}

//-----------------------------------------------------------------------
void blockausgabe() {  //Hier wird der Block bewegt, die Farbe wird generiert und gezeichnet
  if (gamemode == 1) {
    //Serial.println("Bin drin");
    if (millisecond % levelspeed == 0) {
      //Serial.println(bewegung);
      if (bewegung && kannweiterfallen()) {
        yPos += 1;
        blockhoehe = blockheight(shapes[randomblock]);
      }
    }
    if (yPos == -1) {
      randomblock = nextblock;
      nextblock = random(0, 7);  // random Block wird gewählt
      if (randomblock == 3) {
        notquader = false;
      } else {
        notquader = true;
      }
      //color = display->color565(0, 255, 0);  //farbe
      xPos = 4;
      yPos = 0;
    }
    drawblock(12, 12, color, nextshapes[nextblock], 4);
    if (/*yPos + blockhoehe > feldHoehe*/ !kannweiterfallen()) {
      Fixblock();
      display->flipDMABuffer();
      yPos = -1;  // der Block wird auf der richtigen Hoehe generiert
    } else if (kannweiterfallen()) {
      drawblock(xPos, yPos, color, shapes[randomblock], 4);
    }
  }
}

void spielfeld() {
  display->fillRect(36, 0, 2, 64, display->color565(0, 0, 255));  //die Spielfeld abgrenzung
  display->fillRect(36, 40, 30, 2, display->color565(0, 0, 255));
}

void steuerung() {
  int breite = blockwidth(shapes[randomblock]);  //Bewegung von rechts nach links, von links nach rechts und schneller nach unten fahren

  if (digitalRead(37) == HIGH) {
    if (millisecond % 10 == 0) {
      if (kannweiterrechts(xPos, yPos, shapes[randomblock], feldBreite)) {
        xPos += 1;
      }
    }
    bewegung = false;
    //Serial.println(xPos);
  } else if (digitalRead(38) == HIGH) {
    if (millisecond % 10 == 0) {
      if (kannwieterlinks(xPos, yPos, shapes[randomblock], feldBreite)) {
        xPos -= 1;
      }
      //xPos = constrain(xPos, 0, feldBreite - breite);
    }
    bewegung = false;
    //Serial.println(xPos);
  } else if (digitalRead(39) == HIGH) {
    bewegung = true;
    levelspeed = 10;
  } else if (digitalRead(35) == HIGH) {
    if (notquader) {
      bewegung = false;
    }
  } else {
    bewegung = true;
    levelspeed = 60 - (level * 10);
  }
}
//------------------------------------------------------------------------ Ab hier alles um den Block zu drehen

void getPivot(blocks shape[4], int* pivotX, int* pivotY) {  //eckpunktpunkt/ pivotpunkt generieren
  int sumX = 0;
  int sumY = 0;  //Mittelpunkt wird errechnet
  for (int i = 0; i < 4; i++) {
    sumX += shape[i].x;
    sumY += shape[i].y;
  }
  *pivotX = sumX / 4;
  *pivotY = sumY / 4;
}

void drehen(blocks shape[4], int px, int py) {  //die Logik hinter dem drehen (muss man nicht verstehen) x = -y und y = x
  if (digitalRead(35) == HIGH) {
    if (nichtdrehen()) {
      //Serial.println(bewegung);
      if (millisecond % 50 == 0) {
        if (notquader) {
          for (int i = 0; i < 4; i++) {
            int x_rel = shape[i].x - px;
            int y_rel = shape[i].y - py;
            int x_rot = -y_rel;
            int y_rot = x_rel;
            shape[i].x = x_rot + px;
            shape[i].y = y_rot + py;
          }
        }
      }
    }
  }
}
//---------------------------------------------------------------------


void tetris1() {
  steuerung();
  blockausgabe();
  getPivot(shapes[randomblock], &pivotX, &pivotY);
  drehen(shapes[randomblock], pivotX, pivotY);
  if (gamemode == 1) {
    spielfeld();
  }
  display->flipDMABuffer();
}
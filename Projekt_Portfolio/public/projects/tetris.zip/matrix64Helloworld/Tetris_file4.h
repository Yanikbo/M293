#include "Print.h"
#include <stdint.h>
#include <cstring>
#include "WString.h"
#include "soc/gpio_sig_map.h"
#include "esp32-hal.h"
#include <sys/_intsup.h>
#include <cstdio>
#include "HardwareSerial.h"
#include <cstdlib>
#include "esp32-hal-gpio.h"
#include <Preferences.h>

void tetrisschreiben() {
  display->setTextSize(2);
  display->setTextColor(display->color565(255, 0, 0));
  display->setCursor(1, 4);
  display->print("T");
  display->setTextColor(display->color565(255, 142, 0));
  display->setCursor(12, 4);
  display->print("E");
  display->setTextColor(display->color565(255, 213, 0));
  display->setCursor(23, 4);
  display->print("T");
  display->setTextColor(display->color565(132, 213, 0));
  display->setCursor(34, 4);
  display->print("R");
  display->setTextColor(display->color565(0, 165, 255));
  display->setCursor(43, 4);
  display->print("I");
  display->setTextColor(display->color565(199, 86, 255));
  display->setCursor(52, 4);
  display->print("S");
}

void clearField() {
  for (int y = 0; y < feldHoehe; y++) {
    for (int x = 0; x < feldBreite; x++) {
      spielfeldraster[x][y] = false;
    }
  }
}

void buttonverteilung() {
  if (digitalRead(38) == HIGH) {
    punktzahl = 0;
    gamemode = 1;
    clearField();
  }
  if (digitalRead(37) == HIGH) {
    gamemode = 4;
  }
}

void farbtogglerechts() {
  bool currentState = digitalRead(39);
  if (lastState == HIGH && currentState == LOW) {
    colorstate++;
    if (colorstate == 7) {
      colorstate = 1;
    }
    Serial.println(colorstate);
  }
  lastState = currentState;
}

void farbtogglelinks() {
  bool currentState = digitalRead(35);
  if (lastStateleft == HIGH && currentState == LOW) {
    colorstate--;
    if (colorstate == 0) {
      colorstate = 6;
    }
    Serial.println(colorstate);
  }
  lastStateleft = currentState;
}

void allcolors() {
  display->fillRect(3, 58, 8, 4, display->color565(255, 0, 0));
  display->fillRect(13, 58, 8, 4, display->color565(255, 142, 0));
  display->fillRect(23, 58, 8, 4, display->color565(255, 213, 0));
  display->fillRect(33, 58, 8, 4, display->color565(132, 213, 0));
  display->fillRect(43, 58, 8, 4, display->color565(0, 165, 255));
  display->fillRect(53, 58, 8, 4, display->color565(199, 86, 255));
}

void choosecolor() {
  switch (colorstate) {
    case 1:
      display->drawRect(2, 57, 10, 6, menucolor);
      color = display->color565(255, 0, 0);
      break;

    case 2:
      display->drawRect(12, 57, 10, 6, menucolor);
      color = display->color565(255, 142, 0);
      break;

    case 3:
      display->drawRect(22, 57, 10, 6, menucolor);
      color = display->color565(255, 213, 0);
      break;

    case 4:
      display->drawRect(32, 57, 10, 6, menucolor);
      color = display->color565(132, 213, 0);
      break;

    case 5:
      display->drawRect(42, 57, 10, 6, menucolor);
      color = display->color565(0, 165, 255);
      break;

    case 6:
      display->drawRect(52, 57, 10, 6, menucolor);
      color = display->color565(199, 86, 255);
      break;
  }
}

void beschriftung() {
  display->fillCircle(18, 32, 2, display->color565(255, 0, 0));
  display->setTextSize(1);
  display->setTextColor(menucolor);
  display->setCursor(24, 29);
  display->print("PLAY");
  display->fillCircle(18, 42, 2, display->color565(255, 222, 0));
  display->setTextColor(menucolor);
  display->setCursor(24, 39);
  display->print("RANK");
}

void Tetris4() {
  if (gamemode == 5) {
    display->clearScreen();
    tetrisschreiben();
    buttonverteilung();
    beschriftung();
    farbtogglerechts();
    farbtogglelinks();
    choosecolor();
    allcolors();
    display->flipDMABuffer();
  }
}
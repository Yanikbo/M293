#include "soc/gpio_sig_map.h"
#include "esp32-hal.h"
#include <sys/_intsup.h>
#include <cstdio>
#include "HardwareSerial.h"
#include <cstdlib>
#include "esp32-hal-gpio.h"
#include <Preferences.h>

void time() {
  delay(10);  // einziger Delay
  millisecond++;
  if (millisecond == 5000) {
    millisecond = 0;
  }
}

void Fixblock() {
  for (int i = 0; i < 4; i++) {
    posX = xPos + shapes[randomblock][i].x;  //xPos / yPos ist die Aktuelle Position auf dem Raster aber nur die obere Ecke den Pivotpunkt mit dem plus rechen der x und y (unten)
    posY = yPos + shapes[randomblock][i].y;  //Variabel aus dem Struct und den Aktuellen Block kann man die ABsolute Position berechnen
    if (posX >= 0 && posX < feldBreite) {
      if (posY >= 0 && posY < feldHoehe) {   //man prüft ob der Block gerade auf einer gültigen x oder y Position sich befindet
        spielfeldraster[posX][posY] = true;  //wird auf true gesetzt und gesagt wo sich der block gerade absolut befindet
      }
    }
  }
}

bool kannwieterlinks(int xPos, int yPos, blocks shape[4], int feldBreite) {
  for (int i = 0; i < 4; i++) {
    int posX = xPos - 1 + shape[i].x;
    if (posX < 0) return false;
    if (spielfeldraster[posX][yPos + shape[i].y]) return false;
  }
  return true;
}

bool kannweiterrechts(int xPos, int yPos, blocks shape[4], int feldBreite) {
  for (int i = 0; i < 4; i++) {
    int posX = xPos + 1 + shape[i].x;
    int posY = yPos + shape[i].y;
    if (posX >= feldBreite) return false;
    if (spielfeldraster[posX][posY]) return false;
  }
  return true;
}

void punkte() {
  int pluspunkte = level * 10;
  anzahlreihen++;
  punktzahl = punktzahl + pluspunkte;
  if (anzahlreihen % 10 == 0) {
    level++;
    if (levelspeed > 10) {
      levelspeed -= 10;
    }
  }
}

void scoreboard() {
  char bufffer[20];
  char buffer1[20];
  display->setTextColor(color);
  display->setTextSize(1);
  display->setCursor(39, 2);
  sprintf(bufffer, "%d", level);
  display->print(bufffer);
  display->setCursor(39, 18);
  sprintf(buffer1, "%d", punktzahl);
  display->print(buffer1);
}


void spielfeldzeichnen() {
  //Serial.println("Bin drin");
  for (int x = 0; x < feldBreite; x++) {   //x-Achse vom Spielfeld
    for (int y = 0; y < feldHoehe; y++) {  //y-Achse vom Spielfeld
      if (spielfeldraster[x][y]) {
        //Serial.println("bist drin");
        display->fillRect(x * globalblocksize, y * globalblocksize, globalblocksize, globalblocksize, color);  //spielfeld wird gezeichnet
      }
    }
  }
}

bool kannweiterfallen() {
  for (int i = 0; i < 4; i++) {
    posX = xPos + shapes[randomblock][i].x;
    posY = yPos + shapes[randomblock][i].y + 1;
    if (posY >= feldHoehe) {
      return false;
    } else if (posY >= 0 && spielfeldraster[posX][posY]) {
      return false;
    }
  }
  return true;
}

void switchmode() {
  if (!kannweiterfallen() && yPos < 1 && xPos == 4) {
    gamemode = 2;
    //Serial.println(gamemode);
  }
}

void highscoraktualisieren() {
    if (punktzahl > topscores[0].nscore) {
    highscore = punktzahl;
    topscores[0].nscore = punktzahl;
    preferences.putInt("highscore", topscores[0].nscore);
  }
}

void Gameover() {
  //Serial.println(posY);
  yPos = 80;
  if (gamemode == 2) {
    display->clearScreen();
    display->setTextColor(display->color565(255, 0, 0));
    display->setTextSize(1);
    display->setCursor(19, 23);
    display->print("Game");
    display->setCursor(19, 31);
    display->print("Over");
    display->flipDMABuffer();
    delay(3000);
    display->clearScreen();
    if (punktzahl >= topscores[2].nscore) {
      gamemode = 3;
      //Serial.println(gamemode);
    } else {
      gamemode = 4;
    }
  }
}

bool nichtdrehen() {
  if (randomblock == 0 && xPos <= 2) {
    return false;
    bewegung = true;
  } else if (xPos <= 1) {
    return false;
    bewegung = true;
  } else if (xPos >= 7) {
    return false;
    bewegung = true;
  } else {
    return true;
  }
}

void down(int starty) {
  for (int y = starty; y > 0; y--) {
    for (int x = 0; x < feldBreite; x++) {
      spielfeldraster[x][y] = spielfeldraster[x][y - 1];
    }
  }

  for (int x = 0; x < feldBreite; x++) {
    spielfeldraster[x][0] = false;
  }
}

void fullline() {
  bool reihevoll[feldHoehe];

  for (int y = 0; y < feldHoehe; y++) {
    reihevoll[y] = false;
  }

  for (int y = 0; y < feldHoehe; y++) {
    voll = true;
    for (int x = 0; x < feldBreite; x++) {
      if (!spielfeldraster[x][y]) {
        voll = false;
        break;
      }
    }
    if (voll) {
      reihevoll[y] = true;
    }
  }
  for (int y = 0; y < feldHoehe; y++) {
    if (reihevoll[y]) {
      for (int x = 0; x < feldBreite; x++) {
        spielfeldraster[x][y] = false;
      }
      down(y);
      punkte();
      y++;
    }
  }
}

void intinierunghighscore() {
  preferences.begin("tetris", false);
  topscores[0].nscore = preferences.getInt("highscore", 0);
  display->clearScreen();
  display->setCursor(39, 30);
  display->setTextSize(1);
  display->print(topscores[0].nscore);
  display->flipDMABuffer();
}

void highscoreanzeige() {
  display->setCursor(39, 30);
  display->setTextSize(1);
  display->print(topscores[0].nscore);
}

void aufnulllstellen() {
  topscores[0].nscore = 0;
  preferences.putInt("highscore", topscores[0].nscore);
  topscores[2].nscore = 0;
  topscores[1].nscore = 0;
  topscores[0].nscore = 0;
}
////----------------------Experiment Zone ----------------------------------------

void tetris2() {
  time();
  display->clearScreen();
  //aufnulllstellen();
  if (gamemode == 1) {
    fullline();
    spielfeldzeichnen();
    scoreboard();
    highscoreanzeige();
    switchmode();
  } else if (gamemode == 2) {
    Gameover();
  }
}

#include "Print.h"
#include <stdint.h>
#include <cstring>
#include "WString.h"
#include "soc/gpio_sig_map.h"
#include "esp32-hal.h"
#include <sys/_intsup.h>
#include <cstdio>
#include "HardwareSerial.h"
#include <cstdlib>
#include "esp32-hal-gpio.h"
#include <Preferences.h>


void nameneingeben() {
  menucolor = display->color565(114, 85, 255);
  textcolor = display->color565(225, 225, 225);
  char buffer[20];
  if (digitalRead(35) == HIGH) {
    if (millisecond % 20 == 0) {
      if (Buchstabe < 'Z') {
        Buchstabe++;
      } else {
        Buchstabe = 'A';
      }
    }
  }
}

void writeEntername() {
  display->setTextColor(menucolor);
  display->setCursor(2, 2);
  display->setTextSize(1);
  display->print("ENTER NAME");
}

void einlogtoggle() {
  bool currentState = digitalRead(39);
  if (millisecond % 20 == 0) {
    if (lastState == LOW && currentState == HIGH) {  //diese Funktion switcht zwischen den 4 verschiedenen modis
      if (buchstabenlocker < 4) {
        buchstabenlocker++;
      }
    }
    lastState = currentState;
  }
}

void nichtokay() {
  display->setTextColor(menucolor);
  display->setCursor(8, 42);
  display->setTextSize(1);
  display->print("OK");
  display->fillCircle(13, 55, 2, display->color565(255, 0, 0));
  display->setCursor(37, 42);
  display->print("NEU");
  display->fillCircle(45, 55, 2, display->color565(255, 222, 0));
  if (digitalRead(37) == HIGH) {
    for (int i = 0; i < 4; i++) {
      namensbuchstaben[i] = 'A';
    }
    buchstabenlocker = 1;
  }
  if (digitalRead(38) == HIGH) {
    gamemode = 4;
  }
}

void buchstabenlock() {
  display->setTextColor(textcolor);
  gamemode = 3;
  display->setTextSize(2);
  //Serial.println(buchstabenlocker);
  switch (buchstabenlocker) {
    case 1:
      ersterbuchstabe = Buchstabe;
      display->setCursor(12, 20);
      display->print(ersterbuchstabe);
      display->fillRect(25, 32, 10, 2, menucolor);
      display->fillRect(38, 32, 10, 2, menucolor);
      break;
    case 2:
      if (buchstabenlocker != 1) {
        namensbuchstaben[0] = ersterbuchstabe;
      }
      zweiterbuchstaben = Buchstabe;
      display->setCursor(12, 20);
      display->print(namensbuchstaben[0]);
      display->setCursor(25, 20);
      display->print(zweiterbuchstaben);
      display->fillRect(38, 32, 10, 2, menucolor);
      break;
    case 3:
      if (buchstabenlocker != 2) {
        namensbuchstaben[1] = zweiterbuchstaben;
      }
      dritterbuchstaben = Buchstabe;
      display->setCursor(12, 20);
      display->print(namensbuchstaben[0]);
      display->setCursor(25, 20);
      display->print(namensbuchstaben[1]);
      display->setCursor(38, 20);
      display->print(dritterbuchstaben);
      break;
    case 4:
      if (buchstabenlocker != 3) {
        namensbuchstaben[2] = dritterbuchstaben;
      }
      display->setCursor(12, 20);
      display->print(namensbuchstaben[0]);
      display->setCursor(25, 20);
      display->print(namensbuchstaben[1]);
      display->setCursor(38, 20);
      display->print(namensbuchstaben[2]);
      nichtokay();
      break;
  }
}

void intinierungrangking() {
  preferences.begin("tetris", true);  // read-only
  size_t bytes = preferences.getBytes("scores", &topscores, sizeof(topscores));
  preferences.end();
}

void saveHighScore() {
  Serial.print("Vor: ");
  Serial.println(topscores[0].nscore);
  preferences.begin("tetris", false);
  preferences.putBytes("scores", (uint8_t*)topscores, sizeof(topscores));
  preferences.end();
  Serial.print("Nach: ");
  Serial.println(topscores[0].nscore);
}

void highscoreaufrufen() {
  display->setTextColor(display->color565(114, 114, 206));
  display->setTextSize(1);
  display->setCursor(3, 2);
  display->print("HIGHSCORE!");
  display->fillRect(0, 12, 64, 2, display->color565(114, 114, 206));

  for (int i = 0; i < 3; i++) {
    display->setCursor(2, 20 + i * 12);
    display->print(i + 1);
    display->print(".");
    display->print(topscores[i].name);
    display->print(" ");
    display->print(topscores[i].nscore);
  }
  preferences.end();
}

void newscoreintinierung() {
  //Serial.println("bin drin!!!");
  strncpy(newScore.name, namensbuchstaben, 3);
  newScore.name[3] = '\0';
  newScore.nscore = punktzahl;
}

void rangsortieren(scores newScore) {
  Serial.println("rangsortieren bin drin");
  scores temp;
  if (newScore.nscore > topscores[0].nscore) {
    topscores[2] = topscores[1];
    topscores[1] = topscores[0];
    topscores[0] = newScore;
    return;
  }
  if (newScore.nscore > topscores[1].nscore) {
    temp = topscores[1];
    topscores[2] = temp;
    topscores[1] = newScore;
    return;
  }
  if (newScore.nscore > topscores[2].nscore) {
    topscores[2] = newScore;
    return;
  }
}

void gamemodewechseln() {
  if (millisecond % 800 == 0) {
    colorstate = 1;
    gamemode = 5;
    //display->clearScreen();
  }
}

void tetris3() {
  if (gamemode == 3) {
    nameneingeben();
    einlogtoggle();
    writeEntername();
    buchstabenlock();
  } else if (gamemode == 4) {
    if (!scoreeingetragen) {
      newscoreintinierung();
      rangsortieren(newScore);
      saveHighScore();
      scoreeingetragen = true;
    }
    highscoreaufrufen();
    gamemodewechseln();
  }
}
/*

*/
////-------------------------------------------------------------------------------------------------------
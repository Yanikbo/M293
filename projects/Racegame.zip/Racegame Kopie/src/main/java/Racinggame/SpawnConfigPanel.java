package Racinggame;

import javax.swing.*;
import java.awt.*;

public class SpawnConfigPanel extends JPanel{
    Spawnpoint target;
    EditorPanel editorPanel;
    JTextField fahrrichtungField;
    JButton applybtn;
    GridBagConstraints c = new GridBagConstraints();

    SpawnConfigPanel() {
        setLayout(new GridBagLayout());
        c.insets = new Insets(5,5,5,5);
        c.anchor = GridBagConstraints.WEST;

        c.gridy = 1;
        c.gridx = 0;
        JLabel fahrrichtungLabel = new JLabel();
        fahrrichtungLabel.setFont(new Font("Arial", Font.BOLD, 16));
        fahrrichtungLabel.setForeground(new Color(90, 100, 115));
        fahrrichtungLabel.setText("Fahrrichtung: ");
        add(fahrrichtungLabel, c);

        c.gridx = 1;
        fahrrichtungField = new JTextField(5);
        add(fahrrichtungField, c);

        c.gridx = 0;
        c.gridy = 0;
        applybtn = new JButton("Übernehmen");
        applybtn.setBackground(new Color(45, 55, 70));
        applybtn.setForeground(	new Color(180, 190, 200));
        applybtn.setOpaque(true);
        applybtn.setBorderPainted(false);
        applybtn.setFocusPainted(false);
        applybtn.addActionListener(e -> applyChanges());
        add(applybtn, c);
    }

    public void setTarget(Spawnpoint part, EditorPanel ed) {
        this.target = part;
        this.editorPanel = ed;
        loadValues();
    }

    public void applyChanges() {
        try {
            double rotation = Double.parseDouble(fahrrichtungField.getText());
            target.rotation = rotation;
            editorPanel.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ungültige Zahlen!");
        }
    }

    private void loadValues() {
        if(target != null) {
            fahrrichtungField.setText(String.valueOf(target.rotation));
        }
    }

    //Finished
}

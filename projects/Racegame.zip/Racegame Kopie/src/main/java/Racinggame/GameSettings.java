package Racinggame;

import java.awt.*;

public class GameSettings {
    public double speed;
    public double acc;
    public double pbreak;

    public Color firstColor;
    public Color secondColor;
    public Color thirdColor;

    public GameSettings(int speed, int acc, int pbreak, Color fcolor, Color scolor, Color tcolor) {
        this.speed = (double) speed/ 10.0;
        this.acc = (double) acc/ 100.0;
        this.pbreak = (double) pbreak / 100.0;

        this.firstColor = fcolor;
        this.secondColor = scolor;
        this.thirdColor = tcolor;
    }

    //Finished
}

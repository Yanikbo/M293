package Racinggame;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.io.Serializable;

public class Spawnpoint extends Mappart implements Serializable {
    private static final long serialVersionUID = 1L;
    private int carIndex;  // 0 = Player, 1 = Bot

    public Spawnpoint(int x, int y, int carIndex) {
        this.x = x;
        this.y = y;
        this.carIndex = carIndex;
        this.radius = 10;
        this.rotation = 1.57;
        isEditable = true;
    }

    public int getCarIndex() { return carIndex; }

    public void draw(Graphics2D g2d) {
        super.draw(g2d);
        g2d.setStroke(new BasicStroke(10f));
        if(isSelected) {
            g2d.setColor(new Color(182, 4, 4));
        } else {
            g2d.setColor(Color.BLUE);
        }

        g2d.drawOval((int) (x -radius), (int) (y -radius), (int) (radius * 2), (int) (radius*2));

        g2d.setColor(Color.BLUE);
        g2d.fillOval((int) (x -radius), (int) (y -radius), (int) (radius * 2), (int) (radius*2));
    }

    @Override
    public Shape getShape() {
        return new Ellipse2D.Double(x - radius, y - radius, radius*2, radius*2);
    }
}

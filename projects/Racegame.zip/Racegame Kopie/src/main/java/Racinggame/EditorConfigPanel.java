package Racinggame;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class EditorConfigPanel extends JPanel {
    private Mappart selected;
    private JPanel contentArea = new JPanel(new BorderLayout());
    private EditorPanel editorPanel;
    private BotCar botCar;
    boolean loschen = true;
    String[] partTypes = {"Trackpart","Barrier","Waypoint","Checkpoint"};
    JComboBox<String> dropdown;

    public EditorConfigPanel() {
        setBackground(new Color(180, 190, 200));
        contentArea.setBackground(new Color(180, 190, 200));  // ← HIER!
        contentArea.setOpaque(true);
        setLayout(new BorderLayout());
        add(contentArea, BorderLayout.CENTER);
        dropdown = new JComboBox<>(partTypes);
        generellesMenu();
    }

    public void setSelected(Mappart mappart) {
        this.selected = mappart;
        updateConfig();
    }

    public void setEditor(EditorPanel panel) {
        this.editorPanel = panel;
    }

    private void updateConfig() {
        contentArea.removeAll();
        generellesMenu();
        if (selected != null) {
            JPanel configPanel = getEditorConfigPanel(selected);
            configPanel.setBackground(new Color(180, 190, 200));
            contentArea.add(configPanel, BorderLayout.WEST);  // In contentArea!
        }

        contentArea.revalidate();
        contentArea.repaint();
    }

    public JPanel getEditorConfigPanel(Mappart selected) {
        if(selected instanceof TrackPart) {
            trackConfigPanel trackPanel = new trackConfigPanel();
            trackPanel.setTarget((TrackPart) selected, editorPanel);
            return trackPanel;  // Richtiges Panel returnen
        } else if (selected instanceof Checkpoint) {
            CheckPointConfigPanel checkPanel = new CheckPointConfigPanel();
            checkPanel.setTarget((Checkpoint) selected, editorPanel);
            return checkPanel;
        } else if (selected instanceof Barrier) {
            BarrierConfigPanel barrierPanel = new BarrierConfigPanel();
            barrierPanel.setTarget((Barrier) selected, editorPanel);
            return barrierPanel;
        } else if (selected instanceof Spawnpoint) {
            SpawnConfigPanel spawnPanel = new SpawnConfigPanel();
            spawnPanel.setTarget((Spawnpoint) selected, editorPanel);
            return spawnPanel;
        } else {
            JPanel nonConfigPanel = new JPanel();
            JLabel nonConfigLabel = new JLabel("Diesen Part kannst du nicht einstellen");
            nonConfigPanel.setLayout(new BoxLayout(nonConfigPanel, BoxLayout.Y_AXIS));
            nonConfigLabel.setFont(new Font("Arial", Font.BOLD, 16));
            nonConfigLabel.setForeground(new Color(90, 100, 115));
            nonConfigPanel.add(nonConfigLabel);
            return nonConfigPanel;
        }
    }

    public void generellesMenu() {
        JPanel ButtonPanel = new JPanel();
        ButtonPanel.setBackground(new Color(180, 190, 200));
        ButtonPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,2,5,5);
        c.anchor = GridBagConstraints.EAST;

        c.gridx = 1;
        c.gridy = 0;
        JButton speichernButton = new JButton("Speichern");
        speichernButton.setBackground(new Color(45, 55, 70));
        speichernButton.setForeground(new Color(180, 190, 200));
        speichernButton.setOpaque(true);
        speichernButton.setBorderPainted(false);
        speichernButton.addActionListener(e -> save());
        ButtonPanel.add(speichernButton, c);

        c.gridx = 1;
        c.gridy = 1;
        JButton deleteButton = new JButton("Löschen");
        deleteButton.setBackground(new Color(45, 55, 70));
        deleteButton.setForeground(new Color(180, 190, 200));
        deleteButton.setOpaque(true);
        deleteButton.setBorderPainted(false);
        deleteButton.addActionListener(e -> deletePart());
        ButtonPanel.add(deleteButton, c);

        c.gridx = 1;
        c.gridy = 2;
        JButton AddButton = new JButton("Hinzufügen");
        AddButton.setBackground(new Color(45, 55, 70));
        AddButton.setForeground(new Color(180, 190, 200));
        AddButton.setOpaque(true);
        AddButton.setBorderPainted(false);
        AddButton.addActionListener(e -> addPart());
        ButtonPanel.add(AddButton, c);

        c.gridx = 1;
        c.gridy = 3;
        JButton setBackButton = new JButton("Zurücksetzten");
        setBackButton.setBackground(new Color(45, 55, 70));
        setBackButton.setForeground(new Color(180, 190, 200));
        setBackButton.setOpaque(true);
        setBackButton.setBorderPainted(false);
        setBackButton.addActionListener(e -> setBack());
        ButtonPanel.add(setBackButton, c);

        c.gridx = 0;
        c.gridy = 2;
        ButtonPanel.add(dropdown, c);

        contentArea.add(ButtonPanel, BorderLayout.EAST);
    }

    public void setBack() {
        int antwort = JOptionPane.showConfirmDialog(editorPanel, "Wollen sie wirklich den Track zurück setzten?", "Track Reset", JOptionPane.YES_NO_OPTION);
        if(antwort == JOptionPane.YES_OPTION) {
            editorPanel.parts.clear();
            PartData.allparts.clear();
            PartData.loadFromfile();
            editorPanel.parts.addAll(PartData.getAllparts());
            editorPanel.repaint();
        }
    }

    public void save() {
        PartData.allparts = new ArrayList<>(editorPanel.parts);
        PartData.saveToFile();
        JOptionPane.showMessageDialog(this, "Track gespeichert");
    }

    public void addPart() {
        String selectedItem = (String) dropdown.getSelectedItem();

        switch (selectedItem) {

            case "Trackpart" -> {
                TrackPart part = new TrackPart(1200, 175, 635, 0 );
                editorPanel.parts.add(part);
                PartData.allparts.add(part);
            }
            case "Checkpoint" -> {
                Checkpoint part = new Checkpoint(900, 250, 20, 120, -1.57);
                editorPanel.parts.add(part);
                PartData.allparts.add(part);
            }
            case "Waypoint" -> {
                WayPoint part = new WayPoint(900, 250, 50);
                editorPanel.parts.add(part);
                PartData.allparts.add(part);
            }
            case "Barrier" -> {
                Barrier part = new Barrier(900, 250, 20, 120, -1.57);
                editorPanel.parts.add(part);
                PartData.allparts.add(part);
            }
        }
        editorPanel.repaint();
    }

    public void deletePart() {
        if(selected instanceof Spawnpoint) {
            loschen = false;
        } else {
            loschen = true;
        }
        if(selected != null && loschen) {
            editorPanel.parts.remove(selected);
            PartData.allparts.remove(selected);
            editorPanel.repaint();
        }
    }
}

package Racinggame;

import javax.swing.*;
import java.awt.*;

public class trackConfigPanel extends GeneralConfigPanel {
    TrackPart target;
    private EditorPanel editor;

    trackConfigPanel() {
        super();
        remove(3);
        c.gridx = 2;
        c.gridy = 0;
        JLabel bremsLabel = new JLabel("Bremsfaktor: ");
        bremsLabel.setFont(new Font("Arial", Font.BOLD, 16));
        bremsLabel.setForeground(new Color(90, 100, 115));
        add(bremsLabel, c);

        c.gridy = 1;
        c.gridheight = 2;
        bremsfakt = new JSlider(JSlider.HORIZONTAL,0, 9, 0);
        bremsfakt.setMajorTickSpacing(1);
        bremsfakt.setPaintTicks(true);
        bremsfakt.setPaintLabels(true);
        bremsfakt.setPreferredSize(new Dimension(300, 40));
        add(bremsfakt, c);

        c.gridy = 1;
        c.gridx = 4;
        JButton colorBtn = new JButton("Farbe");
        colorBtn.addActionListener(e -> pickColor());
        add(colorBtn,c);

        applybtn.addActionListener(e -> applyChanges());
    }

    public void setTarget(TrackPart part, EditorPanel ed) {
        this.target = part;
        this.editor = ed;
        loadValues();
    }

    public void applyChanges() {
        try {
            double rotation = Double.parseDouble(rotationField.getText());
            int lange = Integer.parseInt(langeField.getText());
            int resistance = bremsfakt.getValue();

            target.height = lange;
            target.rotation = rotation;
            target.resistance = bremsfakt.getValue() / 10.0;

            editor.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ungültige Zahlen!");
        }
    }

    private void loadValues() {
        if(target != null) {
            rotationField.setText(String.valueOf(target.rotation));
            langeField.setText(String.valueOf(target.height));
            bremsfakt.setValue((int)(target.resistance * 10));
        }
    }

    private void pickColor() {
        Color col = JColorChooser.showDialog(this, "Farbe", target.color);
        if(col != null) {
            target.color = col;
        }
    }

    //Finished
}

package Racinggame;

import java.awt.*;
import java.io.Serializable;

public class Grass extends Drivable implements Serializable {
    private static final long serialVersionUID = 1L;

    public Grass(int x, int y, int w, int h) {
        this.width = w;
        this.height = h;
        this.x = x;
        this.y = y;
        this.color = new Color(81, 133, 4);
        this.Layer = 1;
        this.resistance = 0.5;
        this.isEditable = false;
    }

    public void draw (Graphics2D g2d) {
        g2d.setColor(color);
        g2d.fillRect(x, y, width, height);
    }
}

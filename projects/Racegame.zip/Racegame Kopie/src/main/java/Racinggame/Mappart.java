package Racinggame;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.io.Serializable;

public class Mappart extends JPanel implements Serializable {
    private static final long serialVersionUID = 1L;

    protected int x;
    protected int y;
    protected int width;
    protected int height;
    protected double radius;
    protected Color color;
    protected double rotation;
    protected boolean isSelected;
    public boolean isEditable = true;

    public void draw(Graphics2D g2d) {
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }

    public boolean contains(int mx, int my) {
        return getShape().contains(mx, my);
    }

    public Shape getShape() {
        int rectW = width;
        int rectH = height;

        Rectangle rect = new Rectangle(x, y, rectW, rectH); //nimmt das normale Rechteck ohne rotation

        int cx = x + rectW / 2; //Der Mittelpunkt vom rechteck berechnen
        int cy = y + rectH / 2;

        AffineTransform at = AffineTransform.getRotateInstance(rotation, cx, cy);// Rotation wird als Transformationsobjekt gespeichert, AffineTransform rechnet es so um als wäre es um cx und cy gedreht
        return at.createTransformedShape(rect); //nun wendet man die rotation auf das rechteck an -> gedrehtes Rechteck -> das gedrehte Rechteck wird als Shape returned
    }
}

package Racinggame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class PlayerCar extends Vehicle{
    KeyConfig keyConfig;

    public PlayerCar(int Cx, int Cy,GameSettings pSettings, GamePanel panel, Double Rotation, KeyConfig keyConfig) { //Konstruktor für farben und Position
        super(Cx, Cy, pSettings, panel, Rotation);
        this.keyConfig = keyConfig;
    }

    public void Keys(JPanel panel) {
        this.oberPanel = panel;
        String id = keyConfig.name;

        InputMap im = panel.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW); //Inputmap = eine Tabelle welche die Tasten (Keystrokes) mit Acrtion-Namen (String) verbindet
        ActionMap am = panel.getActionMap(); //Actionmap = Verbindet nun die Actionnamen mit den tatsächlichen Actions

        im.put(KeyStroke.getKeyStroke(keyConfig.getLeft(), 0, false), id +"leftp"); //Verbindet die Taste A mit dem Key(action-Namen) und nennt rotateLeft
        am.put(id +"leftp", new AbstractAction() {                                                       //nun verbindet er rotateLeft mit der tatasächlichen Action(drehen)
            public void actionPerformed(ActionEvent e) {
                left = true;}
        });

        im.put(KeyStroke.getKeyStroke(keyConfig.getLeft(), 0, true), id +"leftr");
        am.put(id +"leftr", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
            left = false;
        }});

        im.put(KeyStroke.getKeyStroke(keyConfig.getRight(), 0, false), id +"rightp");
        am.put(id +"rightp", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                right = true;}
        });

        im.put(KeyStroke.getKeyStroke(keyConfig.getRight(), 0, true), id +"rightr");
        am.put(id +"rightr", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                right = false;}
        });

        im.put(KeyStroke.getKeyStroke(keyConfig.getForward(), 0, false), id +"forwardp");
        am.put(id +"forwardp", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                forward = true;}
        });

        im.put(KeyStroke.getKeyStroke(keyConfig.getForward(), 0, true), id +"forwardr");
        am.put(id +"forwardr", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                forward = false;}
        });

        im.put(KeyStroke.getKeyStroke(keyConfig.getBackward(), 0, false), id +"backwardp");
        am.put(id +"backwardp", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                backward = true;}
        });

        im.put(KeyStroke.getKeyStroke(keyConfig.getBackward(), 0, true), id +"backwardr");
        am.put(id +"backwardr", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                backward = false;}
        });
    }
}
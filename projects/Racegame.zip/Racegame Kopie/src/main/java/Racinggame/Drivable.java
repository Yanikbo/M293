package Racinggame;

public abstract class Drivable extends Mappart{
    protected int Layer;
    protected double resistance;
    //Finished
}

package Racinggame;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.io.Serializable;

public class WayPoint extends Mappart implements Serializable {
    private static final long serialVersionUID = 1L;
    private int index;

    WayPoint(int x, int y, double r) {
        this.x = x;
        this.y = y;
        this.radius = r;
        this.index = index;
        isEditable = true;
    }
    
    public boolean isReached(double carX, double carY) {
        double dx = x - carX; //Distanz zwischen Auto und Punkt
        double dy = y - carY;
        return Math.sqrt(dx*dx + dy*dy) < radius; //Pythagoras: Distanz zischen zwei Punkten wenn sie kleiner als der Radius vom Waypoint ist = true;
    }

    public void draw(Graphics2D g2d) {
        super.draw(g2d);
        g2d.setStroke(new BasicStroke(10f));
        if(isSelected) {
            g2d.setColor(new Color(8, 97, 232));
        } else {
            g2d.setColor(Color.RED);
        }

        g2d.drawOval((int) (x -radius), (int) (y -radius), (int) (radius * 2), (int) (radius*2));

        g2d.setColor(Color.RED);
        g2d.fillOval((int) (x -radius), (int) (y -radius), (int) (radius * 2), (int) (radius*2));
    }

    @Override
    public Shape getShape() {
        return new Ellipse2D.Double(x - radius, y - radius, radius*2, radius*2);
    }
}

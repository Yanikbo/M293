package Racinggame;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Settingpanel extends JPanel {
    playerCard player1;
    playerCard player2;
    playerCard bot;
    JCheckBox toggle;

    Settingpanel(GameFrame game) {
        setLayout(new BorderLayout());

        JPanel tooglePanel = new JPanel();
        toggle = new JCheckBox("2 Player", false);
        toggle.setForeground(new Color(180, 190, 200));
        toggle.setFont(new Font("Arial", Font.BOLD, 15));
        tooglePanel.setLayout(new BorderLayout());
        tooglePanel.setBorder(new EmptyBorder(20, 20, 10, 20));
        tooglePanel.setBackground(new Color(45, 55, 70));
        tooglePanel.add(toggle, BorderLayout.WEST);

        JPanel playerPanel = new JPanel();
        playerPanel.setLayout(new GridLayout(1, 2, 25, 0));
        playerPanel.setBackground(new Color(45, 55, 70));
        playerPanel.setBorder(new EmptyBorder(10, 20, 20, 20));
        player1 = new playerCard("Player:", game);
        player2 = new playerCard("Player 2:", game);
        bot = new playerCard("Bot:", game);
        playerPanel.add(player1);
        playerPanel.add(bot);

        toggle.addActionListener( e-> {
            if(toggle.isSelected()) {
                playerPanel.remove(bot);
                playerPanel.add(player2);
            } else {
                playerPanel.remove(player2);
                playerPanel.add(bot);
            }
            revalidate();
            repaint();
        });

        add(playerPanel, BorderLayout.CENTER);
        add(tooglePanel, BorderLayout.NORTH);
    }

    public JCheckBox getToggle() {
        return toggle;
    }
}

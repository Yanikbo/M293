package Racinggame;

import javax.swing.*;
import java.awt.*;

public class GameFrame extends JFrame {
    GamePanel engine;

    public GameFrame(GameSettings pS, GameSettings bs, GameSettings p2s, boolean twoplayer) {
        setTitle("Race");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        setSize(800, 500);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);

        engine = new GamePanel(pS, bs, p2s, twoplayer);
        add(engine, BorderLayout.CENTER);

        ScorePanel score = new ScorePanel(engine, this);
        add(score, BorderLayout.NORTH);

        setVisible(true);
    }
}

package Racinggame;

public class KeyConfig {
    String name;

    KeyConfig(String name) {
        this.name = name;
    }

    private int left;
    private int right;
    private int forward;
    private int backward;

    public int getBackward() {
        return backward;
    }

    public int getForward() {
        return forward;
    }

    public int getLeft() {
        return left;
    }

    public int getRight() {
        return right;
    }

    public void setBackward(int backward) {
        this.backward = backward;
    }

    public void setForward(int forward) {
        this.forward = forward;
    }

    public void setLeft(int left) {
        this.left = left;
    }

    public void setRight(int right) {
        this.right = right;
    }
}

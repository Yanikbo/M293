package Racinggame;

import javax.swing.*;
import java.awt.*;

public class BarrierConfigPanel extends GeneralConfigPanel {
    JCheckBox checkBox;
    Barrier target;
    EditorPanel editorPanel;

    public BarrierConfigPanel() {
        super();
        c.gridy = 0;
        c.gridx = 2;
        JLabel visualLabel = new JLabel("Sichtbar: ");
        visualLabel.setFont(new Font("Arial", Font.BOLD, 16));
        visualLabel.setForeground(new Color(90, 100, 115));
        add(visualLabel, c);

        c.gridx = 3;
        c.gridy = 0;
        checkBox = new JCheckBox();
        add(checkBox, c);

        applybtn.addActionListener(e -> applyChanges());
    }

    public void setTarget(Barrier part, EditorPanel ed) {
        this.target = part;
        this.editorPanel = ed;
        loadValues();
    }

    public void applyChanges() {
        try {
            double rotation = Double.parseDouble(rotationField.getText());
            int lange = Integer.parseInt(langeField.getText());
            int breite = Integer.parseInt(breiteField.getText());
            boolean sichtbar = checkBox.isSelected();

            target.rotation = rotation;
            target.height = lange;
            target.width = breite;
            target.seeable = sichtbar;
            editorPanel.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ungültige Zahlen!");
        }
    }

    private void loadValues() {
        if(target != null) {
            rotationField.setText(String.valueOf(target.rotation));
            langeField.setText(String.valueOf(target.height));
            breiteField.setText(String.valueOf(target.width));
            checkBox.setSelected(target.seeable);
        }
    }
}

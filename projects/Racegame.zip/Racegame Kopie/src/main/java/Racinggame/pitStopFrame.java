package Racinggame;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class pitStopFrame extends JFrame {
    Settingpanel settingpanel;
    GameFrame gameFrame;
    GameSettings playerGameSettings;
    GameSettings botGameSetting;
    GameSettings player2GameSettings;

    public pitStopFrame() {
        setTitle("Pitstop");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setSize(1100, 700);
        setLocationRelativeTo(null);

        JPanel mainpanel = new JPanel();
        mainpanel.setLayout(new BorderLayout());
        mainpanel.setBackground(new Color(15, 25, 40));
        add(mainpanel, BorderLayout.CENTER);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(new Color(180, 190, 200));
        tabs.setOpaque(false);
        mainpanel.add(tabs, BorderLayout.CENTER);

        JPanel pitStopPanel = new JPanel();
        pitStopPanel.setLayout(new BorderLayout());
        pitStopPanel.setBackground(new Color(15, 25, 40));
        pitStopPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        settingpanel = new Settingpanel(gameFrame);
        pitStopPanel.add(settingpanel, BorderLayout.CENTER);

        JPanel buttonpanel = new JPanel();
        buttonpanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        buttonpanel.setBackground(new Color(15, 25, 40));
        JButton cRButton = new JButton("RACE!!");
        cRButton.setBackground(new Color(45, 55, 70));
        cRButton.setForeground(	new Color(180, 190, 200));
        cRButton.setOpaque(true);
        cRButton.setBorderPainted(false);
        cRButton.setFocusPainted(false);
        cRButton.addActionListener(new addFrameListener(this));
        buttonpanel.add(cRButton);
        pitStopPanel.add(buttonpanel, BorderLayout.SOUTH);

        EditorConfigPanel configPanel = new EditorConfigPanel();
        EditorPanel editorPanel = new EditorPanel(configPanel);

        configPanel.setEditor(editorPanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, editorPanel, configPanel);
        splitPane.setResizeWeight(0.95);  // Editor oben: 60%, Config unten: 40% bei Resize
        splitPane.setDividerLocation(0.95);  // Optional: Initiale Position als Prozentsatz
        splitPane.setBackground(new Color(45, 55, 70));

        JPanel maineditorPanel = new JPanel();
        maineditorPanel.setLayout(new BorderLayout());
        maineditorPanel.add(splitPane, BorderLayout.CENTER);  // SplitPane statt einzelner Panels

        tabs.add("Pitstop", pitStopPanel);
        tabs.add("Editor", maineditorPanel);

        setVisible(true);
    }


    class addFrameListener implements ActionListener {
        JFrame frame;
        @Override
        public void actionPerformed(ActionEvent e) {
            JCheckBox toggle = settingpanel.getToggle();
            boolean twoplayer = toggle.isSelected();

            if(settingpanel.player1.ferrari.isSelected()) {
                playerGameSettings = new GameSettings(
                        settingpanel.player1.speedSlider.getValue(),
                        settingpanel.player1.accSlider.getValue(),
                        settingpanel.player1.breackSlider.getValue(),
                        new Color(220, 30, 30),
                        new Color(150, 15, 15),
                        Color.YELLOW
                );
            }

            if(settingpanel.player1.lamborghni.isSelected()) {
                playerGameSettings = new GameSettings(
                        settingpanel.player1.speedSlider.getValue(),
                        settingpanel.player1.accSlider.getValue(),
                        settingpanel.player1.breackSlider.getValue(),
                        new Color(14, 163, 20),
                        new Color(172, 3, 28),
                        new Color(239, 238, 238)
                );
            }

            if(!twoplayer) {
                if(settingpanel.bot.porsche.isSelected()) {
                    botGameSetting = new GameSettings(
                            settingpanel.bot.speedSlider.getValue(),
                            settingpanel.bot.accSlider.getValue(),
                            settingpanel.bot.breackSlider.getValue(),
                            new Color(237, 237, 237),
                            Color.BLACK,
                            Color.RED
                    );
                }

                if(settingpanel.bot.bmw.isSelected()) {
                    botGameSetting = new GameSettings(
                            settingpanel.bot.speedSlider.getValue(),
                            settingpanel.bot.accSlider.getValue(),
                            settingpanel.bot.breackSlider.getValue(),
                            new Color(2, 113, 243),
                            Color.RED,
                            new Color(225, 224, 224)
                    );
                }
            } else {
                if(settingpanel.player2.porsche.isSelected()) {
                    player2GameSettings = new GameSettings(
                            settingpanel.player2.speedSlider.getValue(),
                            settingpanel.player2.accSlider.getValue(),
                            settingpanel.player2.breackSlider.getValue(),
                            new Color(237, 237, 237),
                            Color.BLACK,
                            Color.RED
                    );
                }

                if(settingpanel.player2.bmw.isSelected()) {
                    player2GameSettings = new GameSettings(
                            settingpanel.player2.speedSlider.getValue(),
                            settingpanel.player2.accSlider.getValue(),
                            settingpanel.player2.breackSlider.getValue(),
                            new Color(2, 113, 243),
                            Color.RED,
                            new Color(225, 224, 224)
                    );
                }
            }

            frame.dispose();
            gameFrame = new GameFrame(playerGameSettings, botGameSetting, player2GameSettings, twoplayer);
        }

        public addFrameListener(JFrame frame) {
            this.frame = frame;
        }
    }

    public static void main(String args[]) {
        //PartData.loadFromfile();
        PartData.buildDefaultTrack();
        new pitStopFrame();
    }
}

package Racinggame;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class PartData {
    public static ArrayList<Mappart> allparts = new ArrayList<>();

    public static ArrayList<Mappart> getAllparts() {
        return allparts;
    }

    public static void buildDefaultTrack() {
        //====================================Gras ==========================================================
        Grass grasArena = new Grass(45, 70, 1885, 1025); //gras
        allparts.add(grasArena);

        //==================================Trackparts ======================================================
        allparts.add(new TrackPart(925, 110, 1700, -1.57));
        allparts.add(new TrackPart(890, -225, 1400, 2));
        allparts.add(new TrackPart(240, 155, 250, -2.7));
        allparts.add(new TrackPart(483, 518, 400, 2));
        allparts.add(new TrackPart(200, 515, 250, -1.57));
        allparts.add(new TrackPart(90, 625, 350, 0));
        allparts.add(new TrackPart(455, 165, 625, 2));
        allparts.add(new TrackPart(690, 575, 250, -2.7));
        allparts.add(new TrackPart(1755, 175, 820, 0));
        allparts.add(new TrackPart(1550, 175, 635, 0 ));
        allparts.add(new TrackPart(1650, 75, 250, -1.57));

        //====================================Checkpoint====================================================
        allparts.add(new Checkpoint(130, 800, 120, 20, -1.57));
        allparts.add(new Checkpoint(900, 475, 20, 120, 2));
        allparts.add(new Checkpoint(1590, 550, 120, 20, -1.57));
        allparts.add(new Checkpoint(1795, 550, 120, 20, -1.57));
        allparts.add(new Checkpoint(950, 900, 120, 20));

        //================================Waypoints ===========================================================
        allparts.add(new WayPoint(200, 960, 50)); //1.Rechtskurve
        allparts.add(new WayPoint(150, 650, 50)); // 2.Rechtskurve/leichte Schräge
        allparts.add(new WayPoint(675, 775, 50)); // 1.Linkskurve
        allparts.add(new WayPoint(775, 600, 50)); //untere mittlere Gerade
        allparts.add(new WayPoint(300, 375, 50)); //3.Rechtskurve
        allparts.add(new WayPoint(350, 200, 50)); //lange mittlere Gerade
        allparts.add(new WayPoint(1000, 500, 50)); //1.Rechte Gerade
        allparts.add(new WayPoint(1550, 760, 50)); //4.Rechtskurve
        allparts.add(new WayPoint(1600, 250, 50)); //3.Linkskurve
        allparts.add(new WayPoint(1800, 200, 50)); //5.Rechtskurve/ lange Gerade
        allparts.add(new WayPoint(1800, 910, 50));
        allparts.add(new WayPoint(950, 960, 50));

        //==========================Barriers ======================================================================
        allparts.add(new Barrier(25, 50, 1925, 20, false));
        allparts.add(new Barrier(25, 50, 20, 1025, false));
        allparts.add(new Barrier(1930, 50, 20, 1025, false));
        allparts.add(new Barrier(25, 1075, 1925, 20, false));
        allparts.add(new Barrier(800, 60, 5, 900, 2));
        allparts.add(new Barrier(300, 875, 1400, 5));
        allparts.add(new Barrier(1700, 300, 5, 550));
        allparts.add(new Barrier(350, 200, 5, 650, 2));

        //===========================SpawnPoints=====================================================================
        allparts.add(new Spawnpoint(800, 965, 0));
        allparts.add(new Spawnpoint(800, 925, 1));
    }

    public static void saveToFile() {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("track.dat"))) {
            oos.writeObject(allparts);
            System.out.println("Gespeichert");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean loadFromfile() {
        File file = new File("track.dat");
        if(!file.exists()) {
            buildDefaultTrack();
            return false;
        }

        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            allparts = (ArrayList<Mappart>) ois.readObject();
            System.out.println("Track geladen");
            return true;
        }catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}

package Racinggame;

import java.awt.*;
import java.util.ArrayList;

public class BotCar extends Vehicle{

    private ArrayList<WayPoint> wayPoints = new ArrayList<WayPoint>();
    private int currentWayPoint = 0;
    private boolean finished = false;
    private CheckPointSystem cps;

    public BotCar(int Cx, int Cy, CheckPointSystem cps, GameSettings bSettings, GamePanel gamePanel, ArrayList<Mappart> allParts, double Rotation) { //Konstruktor für farben und Position
        super(Cx, Cy,bSettings, gamePanel, Rotation);
        this.allParts = allParts;
        wayPoints = getWayPoints();
        this.cps = cps;
    }

    public ArrayList<WayPoint> getWayPoints() {
        for(Mappart p : allParts) {
            if(p instanceof WayPoint wayPoint) {
                wayPoints.add(wayPoint);
            }
        }

        return  wayPoints;
    }

    public void steering() {
        if(wayPoints == null || wayPoints.isEmpty()) return; //Falls keine Waypoints vorhanden sind return

        if(finished) { //wenn das rennen vorbei ist alles auf false und return
            forward = false;
            backward = false;
            return;
        }

        WayPoint target = wayPoints.get(currentWayPoint); //es wird der nächste waypoint als Ziel festgelegt

        if(target.isReached((double) centerX, (double) centerY)) { //Wenn das target/ nächste Waypoint erreicht ist:
            currentWayPoint = (currentWayPoint + 1) % wayPoints.size(); //nächster Waypoint festlegen -> Modulo verhindert das überschreiter der Grösse des Arrays
            if(cps.raceFinished()) {
               finished = true;
               forward = false;
               backward = false;
               return;
            }
            target = wayPoints.get(currentWayPoint); //neues Target setzten
        }

        double dx = target.x - centerX; //Differenz zwischen auto und Punkt
        double dy = target.y - centerY;
        double targetAngle = Math.atan2(dy, dx); // Winkel zum Waypoint
        double carAngle = rotation + Math.PI / 2; //Winkel von Auto
         //KI-Mathe
        double angleDiff = targetAngle - carAngle; //Differenz von autowinkel und waypoint winkel
        while (angleDiff > Math.PI) angleDiff -= 2 * Math.PI; //kürzeste Drehung wird berechnet (wenn -120 dreht es nicht 240 grad sondern nur 120)
        while (angleDiff < -Math.PI) angleDiff += 2 * Math.PI;

        if(angleDiff < -Math.toRadians(5)) { //Wenn das Auto mehr als 5 grad vom winkel weg zeigt und dann drehen soll => sobald das target erreicht ist wird das nächste festgelegt
            left = true;                 //dieses ist zu steil rechts -> überschreitet winkel und lenkt dann ein
            right = false;
        } else if (angleDiff > Math.toRadians(5)) {
            left = false;
            right = true;
        } else {
            left = false;
            right = false;
        }

        forward = true;
        backward = false;
    }

    @Override
    protected void draw(Graphics2D g2) {
        steering();
        super.draw(g2);
    }
}

package Racinggame;

import javax.swing.*;
import java.awt.*;

public class GeneralConfigPanel extends JPanel {
    JTextField rotationField;
    JTextField langeField;
    JTextField breiteField;
    JSlider bremsfakt;
    JButton applybtn;
    GridBagConstraints c = new GridBagConstraints();

    public GeneralConfigPanel() {
        setLayout(new GridBagLayout());
        setBackground(new Color(180, 190, 200));
        c.insets = new Insets(5,5,5,5);
        c.anchor = GridBagConstraints.WEST;

        c.gridx = 0;
        c.gridy = 0;
        JLabel rotLabel = new JLabel("Rotation: ");
        rotLabel.setFont(new Font("Arial", Font.BOLD, 16));
        rotLabel.setForeground(new Color(90, 100, 115));
        add(rotLabel, c);

        c.gridx = 1;
        c.weightx = 1.0;
        rotationField = new JTextField(5);
        add(rotationField, c);

        c.gridx = 0;
        c.gridy = 2;

        c.weightx = 0;
        JLabel breitLabel = new JLabel("Breite: ");
        breitLabel.setFont(new Font("Arial", Font.BOLD, 16));
        breitLabel.setForeground(new Color(90, 100, 115));
        add(breitLabel, c);

        c.gridx = 1;
        breiteField = new JTextField(5);
        add(breiteField, c);


        c.gridx = 0;
        c.gridy = 1;
        JLabel langLabel = new JLabel("Länge: ");
        langLabel.setFont(new Font("Arial", Font.BOLD, 16));
        langLabel.setForeground(new Color(90, 100, 115));
        add(langLabel, c);

        c.gridx = 1;
        langeField = new JTextField(5);
        add(langeField, c);

        c.gridx = 4;
        c.gridy = 0;
        applybtn = new JButton("Übernehmen");
        applybtn.setBackground(new Color(45, 55, 70));
        applybtn.setForeground(	new Color(180, 190, 200));
        applybtn.setOpaque(true);
        applybtn.setBorderPainted(false);
        applybtn.setFocusPainted(false);
        add(applybtn, c);
    }

    //Finished
}

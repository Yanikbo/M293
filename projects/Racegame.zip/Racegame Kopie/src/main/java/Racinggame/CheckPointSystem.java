package Racinggame;

import java.awt.*;
import java.awt.geom.Area;
import java.lang.foreign.Arena;
import java.sql.Array;
import java.util.ArrayList;

public class CheckPointSystem {
    private int anzahlrunden;
    ArrayList<Mappart> allParts;
    ArrayList<Checkpoint> checkpoints;
    private int lapCount = 0;
    private int currentCheckPoint = 0;
    private boolean[] alreadyCrossed;
    private String driverName;


    public CheckPointSystem(int anzahlrunden, ArrayList<Mappart> cPs, String dn) {
        this.anzahlrunden = anzahlrunden;
        this.allParts = cPs;
        this.checkpoints = getCheckpoints();
        this.alreadyCrossed = new boolean[checkpoints.size()];
        this.driverName = dn;
    }

    public ArrayList<Checkpoint> getCheckpoints() {
        ArrayList<Checkpoint> checkpoints = new ArrayList<>();
        for(Mappart p : allParts) {
            if(p instanceof Checkpoint cp) {
                checkpoints.add(cp);
            }
        }
        return checkpoints;
    }

    public boolean checkLapProgress(Rectangle carHitBox) {
        Shape checkPointShape = checkpoints.get(currentCheckPoint).getShape();

        // Area aus beiden Shapes erstellen
        Area carArea = new Area(carHitBox);
        Area cpArea = new Area(checkPointShape);

        // Überschneidung prüfen
        carArea.intersect(cpArea);

        if(!carArea.isEmpty() && !alreadyCrossed[currentCheckPoint]) {
            alreadyCrossed[currentCheckPoint] = true;
            currentCheckPoint++;
            if(currentCheckPoint >= checkpoints.size()) {
                lapfinished();
                return true;
            }
        }
        return false;
    }

    public boolean raceFinished() {
        if(lapCount >= anzahlrunden) {
            return true;
        }
        return false;
    }

    public void lapfinished() {
        lapCount++; //hier wird der Lapcount erhöht
        resetCheckpoints(); // alle checkpoint aus dem array werden wieder auf flase gesetzt das sie wieder passiert werden könen
    }

    public void resetCheckpoints() {
        currentCheckPoint = 0;
        for (int i = 0; i < alreadyCrossed.length; i++) {
            alreadyCrossed[i] = false;
        }
    }

    public int getLapCount() {
        return lapCount;
    }

    public int getCurrentCheckPoint() {
        return currentCheckPoint;
    }

    public String getDriverName() {
        return driverName;
    }

}
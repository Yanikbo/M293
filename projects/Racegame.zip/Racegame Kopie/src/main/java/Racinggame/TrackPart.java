package Racinggame;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.io.Serializable;

public class TrackPart extends Drivable implements Serializable {

    TrackPart(int x, int y, int height, double radius) {
        this.x = x;
        this.y = y;
        this.height = height;
        this.width = 100;
        this.rotation = radius;
        this.Layer = 2;
        this.resistance = 0.0;
        this.color = new Color(176, 174, 174);
        isEditable = true;
    }

    public void draw(Graphics2D g2d) {
        double angleRad = rotation; // rotation sollte double sein in Radiant

        int rectW = width;
        int rectH = height;

        int cx = x + rectW / 2;
        int cy = y + rectH / 2;

        AffineTransform old = g2d.getTransform();
        g2d.rotate(angleRad, cx, cy);

        g2d.setColor(color);
        g2d.fillRect(x, y, rectW, rectH);
        g2d.setStroke(new BasicStroke(5f));
        if(isSelected) {
            g2d.setColor(new Color(8, 97, 232));
        } else {
            g2d.setColor(color);
        }

        g2d.drawRect(x, y, rectW, rectH);

        g2d.setTransform(old);
    }
}

package Racinggame;

import javax.swing.*;
import java.awt.*;

public class CheckPointConfigPanel extends GeneralConfigPanel {
    Checkpoint target;
    EditorPanel editorPanel;

    CheckPointConfigPanel() {
        super();
        c.gridy = 0;
        c.gridx = 2;
        JButton colorBtn = new JButton("Farbe");
        colorBtn.addActionListener(e -> pickColor());
        add(colorBtn,c);

        applybtn.addActionListener(e -> applyChanges());
    }

    public void setTarget(Checkpoint part, EditorPanel ed) {
        this.target = part;
        this.editorPanel = ed;
        loadValues();
    }

    public void applyChanges() {
        try {
            double rotation = Double.parseDouble(rotationField.getText());
            int lange = Integer.parseInt(langeField.getText());
            int breite = Integer.parseInt(breiteField.getText());

            target.height = lange;
            target.rotation = rotation;
            target.width = breite;

            editorPanel.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ungültige Zahlen!");
        }
    }

    private void loadValues() {
        if(target != null) {
            rotationField.setText(String.valueOf(target.rotation));
            langeField.setText(String.valueOf(target.height));
            breiteField.setText(String.valueOf(target.width));
        }
    }

    private void pickColor() {
        Color col = JColorChooser.showDialog(this, "Farbe", target.color);
        if(col != null) {
            target.color = col;
        }
    }
    //Finished
}

package Racinggame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

public class GamePanel extends JPanel{
    //Settings laden
    GameSettings pSettings;
    GameSettings bSettings;
    GameSettings p2Settings;

    //Alle ArrayLists zum Ausgeben
    ArrayList<Mappart> allparts;
    ArrayList<Vehicle> cars;
    ArrayList<Barrier> barriers;
    Grass grasArena;
    BotCar bot;
    PlayerCar c1;
    PlayerCar c2;

    //Lap/ Checkpoint-Logik:
    private CheckPointSystem checkPointSystemPlayer;
    private CheckPointSystem checkPointSystemBot;
    CheckPointSystem checkPointSystemPlayer2;
    private ArrayList<CheckPointSystem> allcheckPointSystems;
    private int lapCount;
    private int currentCheckPoint;
    private int playerTwolapCount;
    private int playertwocurrentPoint;
    private int anzahlLaps;
    private boolean playerWon = false;
    private boolean player2Won = false;
    private boolean botWon = false;
    private boolean racePaused = false;

    private static int WORLD_W = 2000;
    private static int WORLD_H = 1100;

    //Alle Timer:
    private Timer timer;
    private long startTime;
    private String formatedTimeString;
    private int countdown;
    private boolean countingdown = false;

    //Playerkey:
    private KeyConfig p1Konfig;
    private KeyConfig p2Konfig;

    //Twoplayer
    boolean twoPlayer;

    public GamePanel(GameSettings ps, GameSettings bs, GameSettings p2s, boolean twoPlayer) {
        this.pSettings = ps;
        this.bSettings = bs;
        this.p2Settings = p2s;
        this.twoPlayer = twoPlayer;
        startGameQuestion();
    }

    public GamePanel() {}

    public void startCountdown() {
        if (countingdown) return;
        countingdown = true;
        countdown = 3;

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), true); //Elternpanel = this
        dialog.setUndecorated(true); //keine rahmen
        dialog.setSize(400, 200);
        dialog.setLocationRelativeTo(this);

        JLabel label = new JLabel("3", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 100));

        dialog.add(label);

        new Thread(() -> { //neuer thread
            for (int i = 3; i > 0; i--) {
                label.setText(String.valueOf(i));
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                }
            }

            SwingUtilities.invokeLater(() -> {
                dialog.dispose();
                countingdown = false;
                if (timer != null) timer.start();  // GameTimer!
                startTime = System.currentTimeMillis();
            });

            try { Thread.sleep(500); } catch (InterruptedException ex) {}
        }).start();

        dialog.setVisible(true);
    }

    public void startGameQuestion() {
        int antwort = JOptionPane.showConfirmDialog(this, "Neues Rennen starten?", "Neues Rennen", JOptionPane.YES_NO_OPTION);
        if(antwort == JOptionPane.YES_OPTION) {
            if(timer != null) {
                timer.stop();
            }
            initGame();
        } else {
            grasArena = new Grass(0,0,0,0);
            barriers = new ArrayList<Barrier>();
            cars = new ArrayList<Vehicle>();
            checkPointSystemPlayer = new CheckPointSystem(anzahlLaps, new ArrayList<Mappart>(), "Player");

            SwingUtilities.invokeLater(() -> {  //Setzt Task an den schluss das heisst nach dem alles gemacht wurde
                Window window = SwingUtilities.getWindowAncestor(GamePanel.this); //holt sich den obersten Component als den Frame
                if (window != null) {
                    allparts = new ArrayList<>();
                    window.dispose();
                }
            });

            new pitStopFrame();
        }
    }

    public void initGame() {
        setLayout(null); //kein Layout
        cars = new ArrayList<Vehicle>();

        playerWon = botWon = player2Won = false;

        allparts = PartData.getAllparts();

        //===================================Checkpoints =====================================================
        anzahlLaps = 5;
        checkPointSystemPlayer = new CheckPointSystem(anzahlLaps, allparts, "Player");
        checkPointSystemBot = new CheckPointSystem(anzahlLaps, allparts, "Bot");
        checkPointSystemPlayer2 = new CheckPointSystem(anzahlLaps, allparts, "Player2");

        allcheckPointSystems = new ArrayList<>();
        if (twoPlayer) {
            allcheckPointSystems.add(checkPointSystemPlayer);   // 0 → c1
            allcheckPointSystems.add(checkPointSystemPlayer2);  // 1 → c2
        } else {
            allcheckPointSystems.add(checkPointSystemPlayer);   // 0 → c1
            allcheckPointSystems.add(checkPointSystemBot);      // 1 → bot
        }

        lapCount = checkPointSystemPlayer.getLapCount();
        currentCheckPoint = checkPointSystemPlayer.getCurrentCheckPoint();

        playerTwolapCount = checkPointSystemPlayer2.getLapCount();
        playertwocurrentPoint = checkPointSystemPlayer2.getCurrentCheckPoint();

        //========================Auto: =============================================================
        Color darkred = new Color(168, 4, 4);
        Color turkis = new Color(13, 136, 163);
        Color brightBlue = new Color(111, 209, 223);
        Color darkTurkis = new Color(1, 89, 120);
        Mappart Spawn1 = null;
        Mappart Spawn2 = null;

        System.out.println("allparts size " + allparts.size());
        for(Mappart p :allparts) {
            if(p instanceof Spawnpoint sp) {
                if(sp.getCarIndex() == 0) Spawn1 = sp;
                if(sp.getCarIndex() == 1) Spawn2 = sp;
            }
        }

        p1Konfig = new KeyConfig("Player1");
        p1Konfig.setBackward(KeyEvent.VK_S);
        p1Konfig.setLeft(KeyEvent.VK_A);
        p1Konfig.setRight(KeyEvent.VK_D);
        p1Konfig.setForward(KeyEvent.VK_W);

        p2Konfig = new KeyConfig("Player2");
        p2Konfig.setForward(KeyEvent.VK_UP);
        p2Konfig.setBackward(KeyEvent.VK_DOWN);
        p2Konfig.setRight(KeyEvent.VK_RIGHT);
        p2Konfig.setLeft(KeyEvent.VK_LEFT);

        c1 = new PlayerCar(Spawn1.x, Spawn1.y, pSettings, this, Spawn1.rotation, p1Konfig); //Autos erstellen
        c1.Keys(this); //die Key funktion aurufen und das Panel auf das gamepanel setzen
        c1.setParts(allparts);//Barriers hinzufügen
        cars.add(c1);

        if(twoPlayer) {
            c2 = new PlayerCar(Spawn2.x, Spawn2.y, p2Settings, this, Spawn2.rotation, p2Konfig);
            c2.Keys(this);
            c2.setParts(allparts);
            cars.add(c2);
        } else {
            bot = new BotCar(Spawn2.x, Spawn2.y, checkPointSystemPlayer, bSettings, this, allparts, Spawn2.rotation);
            bot.setParts(allparts);
            cars.add(bot);
        }

        timer = new Timer(16, e -> { //Gametimer -> delay 16 = 60Fps wiederholt die driving logik beider autos
            if(racePaused || countingdown) return;

            if(!countingdown) {
                long laufZeitMs = System.currentTimeMillis() - startTime;
                int minuten = (int) (laufZeitMs / 1000 / 60);
                int sekunden = (int) (laufZeitMs / 1000 % 60);
                int millis = (int) (laufZeitMs % 1000);
                formatedTimeString = String.format("%d:%02d:%03d",minuten, sekunden, millis);
            }

            for (int i = 0; i < cars.size(); i++) {
                Vehicle c = cars.get(i);
                c.driving();
                allcheckPointSystems.get(i).checkLapProgress(c.getHitBox());

                if(!playerWon && i == 0 && allcheckPointSystems.get(i).getLapCount() >= anzahlLaps ) {
                    playerWon = true;
                    racePaused = true;
                    JOptionPane.showMessageDialog(this, "Player 1 hat gewonnen!!!");
                    racePaused = false;
                    startGameQuestion();
                }

                if(!twoPlayer) {
                    if(!botWon && i == 1 && allcheckPointSystems.get(i).getLapCount() >= anzahlLaps ) {
                        botWon = true;
                        racePaused = true;
                        JOptionPane.showMessageDialog(this, "Leider Verloren!");
                        racePaused = false;
                        startGameQuestion();
                    }
                } else {
                    if(!player2Won && i == 1 && allcheckPointSystems.get(i).getLapCount() >= anzahlLaps) {
                        player2Won = true;
                        racePaused = true;
                        JOptionPane.showMessageDialog(this, "Player 2 hat gewonnen!!!");
                        racePaused = false;
                        startGameQuestion();
                    }
                }
            }
            repaint();
        });
        startCountdown();

        setBackground(new Color(40, 40, 50, 200)); //schwarzer hintergrund

        setFocusable(true);
        requestFocusInWindow();

        // In initGame() oder paintComponent() einmalig:
        System.out.println("=== ALLE PARTS ===");
        for (Mappart p : allparts) {
            System.out.println(p.getClass().getName()); // .getName() statt .getSimpleName()!
        }
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        //Die dynamische grösse des Fensters:

        double sx = getWidth() / (double) WORLD_W;
        double sy = getHeight() / (double) WORLD_H;
        double s = Math.min(sx, sy);

        int offsetX = (int)((getWidth() - WORLD_W * s) / 2);
        int offsetY = (int)((getHeight() - WORLD_H * s) / 2);

        g2.translate(offsetX, offsetY);
        g2.scale(s, s);

        //Alles zeichnen:

        for(Mappart p : allparts) {
            boolean zeichnen;
            if(p instanceof WayPoint || p instanceof Spawnpoint) {
                zeichnen = false;
            } else if (p instanceof Barrier b && !b.seeable) {
               zeichnen = false;
            } else {
                zeichnen = true;
            }

            if(zeichnen) {
                p.draw(g2);
            }
        }

        for(Vehicle car : cars) {
            car.draw(g2); // in der überschriebenen draw-Methode von BotCar befindet sich seine ganze Steuerungslogik
            car.setParts(allparts);
        }

        g2.dispose();
    }

    public Drivable getCurrentPart(double px, double py) {
        Drivable highest = null;

        for(Mappart p: allparts) {
            if(p instanceof Drivable d && d.getShape().contains(px, py)) {
                if(highest == null || d.Layer > highest.Layer) {
                    highest = d;
                }
            }
        }
        return highest;
    }

    public int getLapCount() {
        return checkPointSystemPlayer != null ? checkPointSystemPlayer.getLapCount() : 0;
    }

    public int getCurrentCheckPoint() {
        return checkPointSystemPlayer != null ? checkPointSystemPlayer.getCurrentCheckPoint() : 0;
    }

    public int getPlayerTwolapCount() {
        return checkPointSystemPlayer2 != null ? checkPointSystemPlayer2.getLapCount() : 0;
    }

    public int getPlayertwocurrentPoint() {
        return checkPointSystemPlayer2 != null ? checkPointSystemPlayer2.getCurrentCheckPoint() : 0;
    }

    public int getAnzahlLaps() {
        return anzahlLaps;
    }

    public String getFormatedTimeString() {
        if(formatedTimeString == null) {
            return "0:00:000";
        } else {
            return formatedTimeString;
        }
    }
}
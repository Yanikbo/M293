package Racinggame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

public class EditorPanel extends JPanel implements MouseListener, MouseMotionListener{
    ArrayList<Mappart> parts;
    private Mappart selected = null;
    private EditorConfigPanel configPanel;
    private int offsetx;
    private int offsety;
    int mx;// Zurückrechnen
    int my;

    public EditorPanel(EditorConfigPanel config) {
        this.configPanel = config;
        this.parts = new ArrayList<>(PartData.getAllparts());
        addMouseListener(this);
        addMouseMotionListener(this);
        setBackground(new Color(81, 133, 4));
    }

    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        super.paintComponent(g);

        AffineTransform old = g2d.getTransform(); // alten Zustand merken

        double scaleX = (double) getWidth() / 1900.0 * 0.85;
        double scaleY = (double) getHeight() / 1000.0 * 0.85;
        double scale = Math.min(scaleX, scaleY);

        g2d.scale(scale, scale);

        for(Mappart p : parts) {
            if(!(p instanceof Grass)) {
                p.draw(g2d);
            }
        }

        g2d.setTransform(old); // Transform zurücksetzen!
    }

    private double getScale() {
        double scaleX = (double) getWidth() / 1900.0 * 0.85;
        double scaleY = (double) getHeight() / 1000.0 * 0.85;

        return Math.min(scaleX, scaleY);
    }

    public void mousePressed(MouseEvent e) {
        double scale = getScale();
        mx = (int)(e.getX() / scale); // Zurückrechnen
        my = (int)(e.getY() / scale);

        selected = null;

        for(int i = parts.size() -1; i >= 0; i--) {
            Mappart p = parts.get(i);
            if(p instanceof Grass) continue;

            if(p.isEditable && p.contains(mx, my)) {
                selected = p;
                configPanel.setSelected(p);
                selected.isSelected = true;
                offsetx = mx - p.x;
                offsety = my - p.y;
                break;
            }
        }
    }

    public void mouseDragged(MouseEvent e) {
        if(selected != null && selected.isEditable) {
            double scale = getScale();
            selected.x = (int)(e.getX() / scale) - offsetx; // <-- mit scale
            selected.y = (int)(e.getY() / scale) - offsety;
            repaint();
        }
    }

    public void mouseReleased(MouseEvent e) {
        try {
            selected.isSelected = false;
        } catch (NullPointerException exception) {}
    }

    //Alle anderen Mouslistener-Methoden:
    public void mouseMoved(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
}

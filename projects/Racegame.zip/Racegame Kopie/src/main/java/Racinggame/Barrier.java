package Racinggame;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;

public class Barrier extends Mappart implements Serializable {
    private static final long serialVersionUID = 1L;
    public boolean seeable;

    public Barrier(int X, int Y, int w, int h) {
        this.x = X;
        this.y = Y;
        this.width = w;
        this.height = h;
        this.isEditable = true;
        this.color = Color.darkGray;
        seeable = true;
    }

    public Barrier(int X, int Y, int w, int h, boolean isEditable) {
        this.x = X;
        this.y = Y;
        this.width = w;
        this.height = h;
        this.color = Color.darkGray;
        this.isEditable = isEditable;
        seeable = true;
    }

    public Barrier(int X, int Y, int w, int h, double rA) {
        this.x = X;
        this.y = Y;
        this.width = w;
        this.height = h;
        this.color = Color.darkGray;
        this.isEditable = true;
        seeable = true;
        this.rotation = rA;
    }

    public void draw (Graphics2D g2) {
        g2.setColor(color);
        super.draw(g2);

        double angleRad = rotation; // rotation sollte double sein in Radiant

        int barW = width;
        int barH = height;

        int cx = x + barW / 2;
        int cy = y + barH / 2;

        AffineTransform old = g2.getTransform();
        g2.rotate(angleRad, cx, cy);

        g2.fillRect(x, y, barW, barH);

        g2.setColor(Color.DARK_GRAY);
        g2.setStroke(new BasicStroke(5f));
        if(isSelected) {
            g2.setColor(new Color(8, 97, 232));
        } else {
            g2.setColor(Color.DARK_GRAY);
        }
        g2.drawRect(x, y, barW, barH);

        g2.setTransform(old);
    }

    public Shape getRotatedHitbox() {
        double centeX = x + width / 2.0;
        double centerY = y + height / 2.0;
        Rectangle2D rect = new Rectangle2D.Double(x, y, width, height);
        AffineTransform transform = AffineTransform.getRotateInstance(rotation,centeX, centerY);
        return transform.createTransformedShape(rect);
    }
}

package Racinggame;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class playerCard extends JPanel {
    String Name;
    GameFrame game;
    JSlider speedSlider;
    JSlider accSlider;
    JSlider breackSlider;
    JRadioButton bmw;
    JRadioButton porsche;
    JRadioButton lamborghni;
    JRadioButton ferrari;

    public playerCard(String name, GameFrame game) {
        this.Name = name;
        this.game = game;

        setBackground(new Color(180, 190, 200));
        setOpaque(false);
        setLayout(new GridLayout(10, 1, 0, 5));
        setBorder(new EmptyBorder(10, 10, 10 , 10));

        JLabel namenLabel = new JLabel(Name);
        namenLabel.setFont(new Font("Arial", Font.BOLD, 24));
        namenLabel.setForeground(new Color(90, 100, 115));
        add(namenLabel);

        JLabel speedLabel = new JLabel("Geschwindigkeit:");
        speedLabel.setFont(new Font("Arial",Font.BOLD, 18));
        speedLabel.setForeground(new Color(90, 100, 115));
        add(speedLabel);

        speedSlider = new JSlider(0, 50, 35);
        speedSlider.setMajorTickSpacing(5);
        speedSlider.setPaintTicks(true);
        speedSlider.setPaintLabels(true);
        add(speedSlider);

        JLabel accLabel = new JLabel("Beschleunigung:");
        accLabel.setFont(new Font("Arial",Font.BOLD, 18));
        accLabel.setForeground(new Color(90, 100, 115));
        add(accLabel);

        accSlider = new JSlider(0, 20, 10);
        accSlider.setMajorTickSpacing(2);
        accSlider.setPaintTicks(true);
        accSlider.setPaintLabels(true);
        add(accSlider);

        JLabel breakLabel = new JLabel("Bremsen:");
        breakLabel.setFont(new Font("Arial",Font.BOLD, 18));
        breakLabel.setForeground(new Color(90, 100, 115));
        add(breakLabel);

        breackSlider = new JSlider(1, 10, 5);
        breackSlider.setMajorTickSpacing(1);
        breackSlider.setPaintTicks(true);
        breackSlider.setPaintLabels(true);
        add(breackSlider);

        JLabel colorLabel = new JLabel("Team:");
        colorLabel.setFont(new Font("Arial",Font.BOLD, 18));
        colorLabel.setForeground(new Color(90, 100, 115));
        add(colorLabel);
        ButtonGroup colorChooser = new ButtonGroup();

        if(Name.equals("Bot:") || Name.equals("Player 2:")) {
            bmw = new JRadioButton("BMW-Racing");
            bmw.setBackground(new Color(180, 190, 200));
            bmw.setOpaque(true);
            bmw.setSelected(true);
            bmw.setForeground(new Color(90, 100, 115));
            bmw.setFont(new Font("Arial", Font.BOLD, 15));
            colorChooser.add(bmw);
            add(bmw);

            porsche = new JRadioButton("Porsche-Racing");
            porsche.setBackground(new Color(180, 190, 200));
            porsche.setOpaque(true);
            porsche.setSelected(true);
            porsche.setForeground(new Color(90, 100, 115));
            porsche.setFont(new Font("Arial", Font.BOLD, 15));
            colorChooser.add(porsche);
            add(porsche);
        } else {
            lamborghni = new JRadioButton("Lamborghini-Racing");
            lamborghni.setBackground(new Color(180, 190, 200));
            lamborghni.setOpaque(true);
            lamborghni.setSelected(true);
            lamborghni.setForeground(new Color(90, 100, 115));
            lamborghni.setFont(new Font("Arial", Font.BOLD, 15));
            colorChooser.add(lamborghni);
            add(lamborghni);

            ferrari = new JRadioButton("Ferrari-Racing");
            ferrari.setBackground(new Color(180, 190, 200));
            ferrari.setOpaque(true);
            ferrari.setSelected(true);
            ferrari.setForeground(new Color(90, 100, 115));
            ferrari.setFont(new Font("Arial", Font.BOLD, 15));
            colorChooser.add(ferrari);
            add(ferrari);
        }

    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(new Color(180, 190, 200));
        g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
        g2d.dispose();
    }
}

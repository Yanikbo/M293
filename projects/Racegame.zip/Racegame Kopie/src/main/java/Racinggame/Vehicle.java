package Racinggame;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

public class Vehicle {
    GameSettings gameSettings;
    GamePanel gPanel;

    //Coordinates
    protected final int CAR_WIDTH = 24;
    protected final int CAR_HEIGHT = 40;
    protected int centerX;
    protected int centerY;
    protected double x;
    protected double y;

    //Movement
    protected double rotateSpeed;
    protected double rotation = 1.57;
    protected double turnspeed; //Bedeutet so viel wie so viel Grad pro frame drehen
    protected double speed = 0.0;
    protected double maxspeed;
    protected double acc;
    protected double gacc;
    protected double brea;
    protected double bacc;
    protected double gbacc;
    protected double slowdown;
    protected double gslowdown;

    //Keys
    protected boolean forward = false;
    protected boolean backward = false;
    protected boolean left = false;
    protected boolean right = false;

    //Color
    protected Color firstcolor;
    protected Color secondcolor;
    protected Color darkcolor;

    protected ArrayList<Mappart> allParts;
    protected JPanel oberPanel;

    public Vehicle(int Cx, int Cy, GameSettings gameSettings, GamePanel gPanel, double rotation) {
        this.x = Cx;
        this.y = Cy;

        this.gameSettings = gameSettings;
        this.gPanel = gPanel;

        this.maxspeed = gameSettings.speed;
        this.acc = gameSettings.acc;
        this.brea = gameSettings.pbreak;
        this.gacc = acc/ 10.0;
        this.bacc = gameSettings.acc /2.0;
        this.gbacc = bacc/ 10.0;
        this.slowdown = brea;
        this.gslowdown = brea *2;
        this.rotateSpeed = maxspeed * 0.571;
        this.turnspeed = Math.toRadians(rotateSpeed);

        this.firstcolor = gameSettings.firstColor;
        this.secondcolor = gameSettings.thirdColor;
        this.darkcolor = gameSettings.secondColor;

        this.rotation = rotation;
    }

    public void setParts(ArrayList<Mappart> mp) {
        this.allParts = mp;
    } //Import von Barrier Liste aus Game

    public ArrayList<Barrier> getBarriers() {
        ArrayList<Barrier> barriers = new ArrayList<>();
        for(Mappart p : allParts) {
            if(p instanceof Barrier b) {
                barriers.add(b);
            }
        }
        return barriers;
    }

    public Rectangle getHitBox() {
        return new Rectangle((int)x, (int)y, CAR_WIDTH, CAR_HEIGHT);
    } //returnt ein imaginäres Rechteck mit der momentanen x und y koordinate und die höhe/ Breite des Autos

    private boolean collision(double newX, double newY) {
        Rectangle futureHitbox = new Rectangle((int)newX, (int)newY, CAR_WIDTH, CAR_HEIGHT); //Nimmt das Rechteck welches er nach der nächsten Aktuallisierung haben wird

        for(Barrier b: getBarriers()) {
            if(b.getRotatedHitbox().intersects(futureHitbox)) { //vergleicht es hier mit allen existierenden Barrieren und ob es eine überschneidung gibt
                return true;
            }
        }
        return false;
    }

    public void driving() {
        Drivable currentPart = gPanel.getCurrentPart(centerX, centerY);
        double resistance = (currentPart != null) ? currentPart.resistance : 0.5;
        double dir = rotation + Math.PI / 2; //Berechnet Richtung in welche das Auto zeigt
        double newX = x + Math.cos(dir) * speed;
        double newY = y + Math.sin(dir) * speed;


        maxspeed = gameSettings.speed * (1.0 - resistance);

        if(left) rotation -= turnspeed; //Erhöt oder senkt die momentane Rotation um 2 Grad pro Frame (oben bei Deklaration schauen)
        if(right) rotation += turnspeed;

        if(forward) {
            if(speed < maxspeed) {
                speed += acc * (1.0 - resistance);
            } else if (speed > maxspeed) { //Falls das Auto über dem aktuellen Maxspeed ist wenn es auf das gras fährt
                speed = maxspeed; //wird der speed auf den aktuellen Highspeed gesenkt
            }
        }

        if(backward) {
            if(speed > 0) {
                speed -= brea; //Wenn der Speed über 0 ist wenn S drückt wird der Speed gesenkt (bremsen)
                if(speed < 0) speed = 0; // Wenn der Speed nach der überprüfung vom Statemant kleiner wie 0 ist, wird der speed nochmals
            }  else {                    // auf 0 gesetzt das er es nicht einfach überspringt
                speed -= bacc * (1.0 - resistance);
            }
        }

        if(!forward && !backward) { //Wenn beide Keys nicht gedrückt sind sollte das Auto in die aktuelle fahrtrichtung (Vorwerts/ Rueckwerts) ausrollen
            if(speed > 0) { //Wenn der Speed grösser wie 0 ist (Vorwärts)
                speed = Math.max(0, speed - slowdown * (1.0 - resistance));
            } else if (speed < 0) { //Das gleiche nur andersherum
                speed = Math.min(0, speed + slowdown * (1.0 - resistance));
            }
        }

        speed = Math.max(-3.0, Math.min(6.0, speed));

        if(!collision(newX, newY)) {
            x = newX; //hier unten wird das Fahren erst wirklich aus geführt aber nur wenn die Kollision false ist
            y = newY;
        } else {
            speed = 0; // wenn Kollision
        }
    }

    protected void draw(Graphics2D g2) {
        driving();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); //zeichnet Ränder weich beim Rotieren

        centerX = CAR_WIDTH/2 + (int)x;
        centerY = CAR_HEIGHT /2 + (int)y; // Das /2 halbiert die Länge und Breite um den Mittelpunkt zu bestimmen + die momentane x/ y koordinate

        AffineTransform transform = g2.getTransform(); //Funktioniert wie ein Buchzeichen es merkt sich den Zustand vor der drehung
        g2.rotate(rotation, centerX, centerY); //rotation = Grad der Drehung, centerX/ Y = das Zentrum von der x/ y-Achse aus


        //=========================================== Auto-Design ======================================================

        g2.setColor(Color.black);
        g2.fillRect(centerX-13, centerY-15, 26, 7);//Räder
        g2.fillRect(centerX-13, centerY+8, 26, 7);
        g2.fillRect(centerX-5, centerY-25, 2, 39);//Auspuff
        g2.fillRect(centerX+3, centerY-25, 2, 39);
        g2.setColor(darkcolor);
        g2.fillRect(centerX -5, centerY -17, 10, 40);//Front
        g2.fillRect(centerX -11, centerY -23, 22, 5);//Spoiler
        g2.setColor(firstcolor);
        g2.fillRect(centerX-11, centerY-19,22, 39);//Body
        g2.setColor(Color.lightGray);
        g2.fillRect(centerX-10, centerY+16, 20, 2); //lichter
        g2.setColor(secondcolor);
        g2.fillRect(centerX-5, centerY-20, 10, 39); //Streifen
        g2.setColor(firstcolor);
        g2.fillRect(centerX-1, centerY-20, 2, 39); //Abstand zwischen Streifen
        g2.setColor(Color.darkGray);
        g2.fillRect(centerX-7, centerY, 14, 8); //Frontscheibe
        g2.fillRect(centerX-8, centerY, 16, 6);
        g2.fillRect(centerX-6, centerY- 11, 12, 4); //Heckscheibe
        g2.fillRect(centerX-4, centerY- 12, 8, 2);
        g2.fillRect(centerX-8, centerY-7, 2, 6); //Seitenscheiben
        g2.fillRect(centerX+6, centerY-7, 2, 6);

        g2.setTransform(transform); //ruft nun den gespeichert "vorher" Zustand wieder auf um nur das auto zu drehen
    }
}

package Racinggame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ScorePanel extends JPanel {
    GamePanel game;
    JFrame frame;

    public ScorePanel(GamePanel game, JFrame frame) {
        this.frame = frame;
        this.game = game;
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(800, 100));
        setBackground(new Color(20, 22, 25, 210));
        Timer updateTimer = new Timer(100, e -> repaint());
        updateTimer.start();
        JPanel buttonpanel = new JPanel();
        buttonpanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        JButton pitstopButton = new JButton("Pitstop");
        pitstopButton.addActionListener(new pitStopListener());
        buttonpanel.add(pitstopButton);
        buttonpanel.setBackground(new Color(20, 22, 25, 0));
        add(buttonpanel, BorderLayout.SOUTH);
    }

    class pitStopListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            frame.dispose();
            new pitStopFrame();
        }
    }

    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        super.paintComponent(g);

        g2d.setColor(Color.white);
        g2d.setFont(new Font("Arial", Font.BOLD, 24));
        g2d.drawString("Lap: " + (game.getLapCount() + 1) + "/" + game.getAnzahlLaps(), 20, 30);
        g2d.drawString("Checkpoint: " + (game.getCurrentCheckPoint() + 1), 20, 75);
        g2d.setFont(new Font("Arial", Font.BOLD, 30));
        g2d.drawString("Zeit: " + game.getFormatedTimeString() + "s", getWidth()/2 - 90, 52);

        if(game.twoPlayer) {
            g2d.setColor(Color.white);
            g2d.setFont(new Font("Arial", Font.BOLD, 24));
            g2d.drawString("Lap: " + (game.getPlayerTwolapCount() + 1) + "/" + game.getAnzahlLaps(), 300, 30);
            g2d.drawString("Checkpoint: " + (game.getPlayertwocurrentPoint() + 1), 300, 75);
            g2d.setFont(new Font("Arial", Font.BOLD, 30));
            g2d.drawString("Zeit: " + game.getFormatedTimeString() + "s", getWidth()/2 - 90, 52);
        }
    }
}

package Racinggame;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.io.Serializable;

public class Checkpoint extends Mappart implements Serializable {
    private static final long serialVersionUID = 1L;

    Checkpoint(int x, int y, int height, int width) {
        this.x = x;
        this.y = y;
        this.height = height;
        this.width = width;
        isEditable = true;
    }

    Checkpoint(int x, int y, int height, int width, double rotation) {
        this.x = x;
        this.y = y;
        this.height = height;
        this.width = width;
        this.rotation = rotation;
        this.color = Color.YELLOW;
        isEditable = true;
    }

    public void draw(Graphics2D g2d) {
        double angleRad = rotation; // rotation sollte double sein in Radiant

        int rectW = width;
        int rectH = height;

        int cx = x + rectW / 2;
        int cy = y + rectH / 2;

        AffineTransform old = g2d.getTransform();
        g2d.rotate(angleRad, cx, cy);

        g2d.setColor(color);
        g2d.fillRect(x, y, rectW, rectH);
        g2d.setStroke(new BasicStroke(5f));
        if(isSelected) {
            g2d.setColor(new Color(8, 97, 232));
        } else {
            g2d.setColor(color);
        }

        g2d.drawRect(x, y, rectW, rectH);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setTransform(old);
    }
}
